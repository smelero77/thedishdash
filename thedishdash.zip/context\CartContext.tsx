'use client';

import React, { createContext, useContext, ReactNode } from 'react';
import { Cart, CartItem, MenuItemData } from '@/types/menu';
import useCart from '@/hooks/useCart';
import { useTable } from './TableContext';

interface CartContextType {
  cart: Cart;
  cartTotal: number;
  addToCart: (itemId: string, modifiers: Record<string, any>) => void;
  removeFromCartByItem: (itemId: string, modifiers: Record<string, any>) => void;
  removeFromCartByKey: (key: string) => void;
  getTotalItems: () => number;
  getItemQuantity: (itemId: string) => number;
  findCartKey: (itemId: string, modifiers: Record<string, any>) => string | null;
  findExactCartKey: (itemId: string, modifiers: Record<string, any>) => string | null;
  calculateItemPrice: (itemId: string, modifiers: Record<string, any>) => number;
  decrementCart: (itemId: string, modifiers: Record<string, any>) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

interface CartProviderProps {
  children: ReactNode;
  menuItems: MenuItemData[];
  slotId: string;
  alias: string;
  tableCode: string;
}

export function CartProvider({ children, menuItems, slotId, alias, tableCode }: CartProviderProps) {
  const { tableNumber } = useTable();

  const {
    cart,
    cartTotal,
    handleAddToCart,
    handleDecrementCart,
    handleRemoveFromCartByItem,
    handleRemoveFromCartByKey,
    getTotalItems,
    getItemQuantity,
    findCartKey,
    findExactCartKey,
    calculateItemPrice,
  } = useCart(menuItems, alias, tableNumber);

  // Simplificar las funciones
  const addToCart = handleAddToCart;
  const decrementCart = handleDecrementCart;
  const removeFromCartByItem = handleRemoveFromCartByItem;
  const removeFromCartByKey = handleRemoveFromCartByKey;

  const value: CartContextType = {
    cart,
    cartTotal,
    addToCart,
    decrementCart,
    removeFromCartByItem,
    removeFromCartByKey,
    getTotalItems,
    getItemQuantity,
    findCartKey,
    findExactCartKey,
    calculateItemPrice,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

// Configuración de why-did-you-render para el CartProvider
CartProvider.whyDidYouRender = {
  logOnDifferentValues: true,
  customName: 'CartProvider',
};

export function useCartContext() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCartContext must be used within a CartProvider');
  }
  return context;
}
