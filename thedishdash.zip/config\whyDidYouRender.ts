'use client';

import React from 'react';
import whyDidYouRender from '@welldone-software/why-did-you-render';

// Asegurarnos de que solo se ejecute en el cliente
if (typeof window !== 'undefined') {
  console.log('NODE_ENV from code:', process.env.NODE_ENV);
  console.log('window is defined:', typeof window !== 'undefined');
  
  // Forzar el modo desarrollo
  if (true) { // Siempre activo para testing
    whyDidYouRender(React, {
      trackAllPureComponents: true,
      trackHooks: true,
      logOnDifferentValues: true,
      collapseGroups: true,
      include: [/^.*$/], // Incluir todos los componentes
      exclude: [], // No excluir ningún componente
      notifier: (options) => {
        console.log('Why did you render:', options);
      }
    });
  }
} 