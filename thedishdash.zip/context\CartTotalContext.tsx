"use client";

import { createContext } from 'react';

export const CartTotalContext = createContext<number | null>(null); 