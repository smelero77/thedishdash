"use client"

import React, { Suspense } from 'react'
import AliasScreen from '@/components/AliasScreen'
import LoadingScreen from '@/components/MenuScreen/LoadingScreen'

export default function AliasPage() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <AliasScreen />
    </Suspense>
  );
} 