"use client"

import React, { Suspense } from 'react'
import MenuScreen from '@/components/MenuScreen'
import LoadingScreen from '@/components/MenuScreen/LoadingScreen'

export default function MenuPage() {
  const initialTableNumber = 0;
  return (
    <Suspense fallback={<LoadingScreen />}>
      <MenuScreen initialTableNumber={initialTableNumber} />
    </Suspense>
  );
} 